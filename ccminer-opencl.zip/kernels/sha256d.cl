#ifndef __OPENCL_TYPEDEFS_H__
#define __OPENCL_TYPEDEFS_H__
typedef unsigned int uint32_t;
#endif

/* SHA256d (Double SHA-256) OpenCL Kernel for Bitcoin-style block headers
 *
 * The block header is 80 bytes. SHA-256 requires two 64-byte blocks.
 * g_in is the full 80-byte header as 20 x uint32_t in little-endian.
 * The nonce at g_in[19] is replaced with the GPU-generated nonce.
 *
 * Target comparison: Full 256-bit comparison using 8 words.
 * The hash is in big-endian word order: h[0] is most significant.
 * The target is also in big-endian word order: target[0] is most significant.
 * A valid share has hash <= target (comparing from most significant word).
 *
 * For efficiency, we pass the target as 8 separate uint32_t arguments
 * rather than a pointer (avoids additional buffer management).
 */
#define TPB 256

__constant uint32_t sha256_k2[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};

#define SHR2(x,n) ((x) >> (n))
#define ROTR2(x,n) (rotate((uint32_t)(x), (uint32_t)(32-(n))))
#define S02(x) (ROTR2(x,2) ^ ROTR2(x,13) ^ ROTR2(x,22))
#define S12(x) (ROTR2(x,6) ^ ROTR2(x,11) ^ ROTR2(x,25))
#define s02(x) (ROTR2(x,7) ^ ROTR2(x,18) ^ SHR2(x,3))
#define s12(x) (ROTR2(x,17) ^ ROTR2(x,19) ^ SHR2(x,10))
#define Ch2(x,y,z) ((x & y) ^ (~x & z))
#define Maj2(x,y,z) ((x & y) ^ (x & z) ^ (y & z))

static inline uint32_t bswap32(uint32_t x) {
    return ((x >> 24) & 0xff) | ((x >> 8) & 0xff00) | ((x << 8) & 0xff0000) | ((x << 24) & 0xff000000);
}

static inline void sha256d_transform(uint32_t *h, const uint32_t *w) {
    uint32_t a=h[0], b=h[1], c=h[2], d=h[3], e=h[4], f=h[5], g=h[6], hh=h[7];
    uint32_t W[64];
    for (int i = 0; i < 16; i++) W[i] = w[i];
    for (int i = 16; i < 64; i++) W[i] = s12(W[i-2]) + W[i-7] + s02(W[i-15]) + W[i-16];
    for (int i = 0; i < 64; i++) {
        uint32_t T1 = hh + S12(e) + Ch2(e,f,g) + sha256_k2[i] + W[i];
        uint32_t T2 = S02(a) + Maj2(a,b,c);
        hh = g; g = f; f = e; e = d + T1; d = c; c = b; b = a; a = T1 + T2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
}

/* Check if hash <= target (256-bit big-endian comparison)
   h[0] is most significant word, h[7] is least significant.
   Same for target. */
static inline int hash_below_target(const uint32_t *h,
                                     uint32_t t0, uint32_t t1, uint32_t t2, uint32_t t3,
                                     uint32_t t4, uint32_t t5, uint32_t t6, uint32_t t7) {
    if (h[0] < t0) return 1;
    if (h[0] > t0) return 0;
    if (h[1] < t1) return 1;
    if (h[1] > t1) return 0;
    if (h[2] < t2) return 1;
    if (h[2] > t2) return 0;
    if (h[3] < t3) return 1;
    if (h[3] > t3) return 0;
    if (h[4] < t4) return 1;
    if (h[4] > t4) return 0;
    if (h[5] < t5) return 1;
    if (h[5] > t5) return 0;
    if (h[6] < t6) return 1;
    if (h[6] > t6) return 0;
    if (h[7] <= t7) return 1;
    return 0;
}

__kernel void sha256d_gpu_hash(__global uint32_t *g_out,
                               __global const uint32_t *g_in,
                               const uint32_t nonce_start,
                               uint32_t t0, uint32_t t1, uint32_t t2, uint32_t t3,
                               uint32_t t4, uint32_t t5, uint32_t t6, uint32_t t7)
{
    int tid = get_global_id(0);
    uint32_t nonce = nonce_start + tid;

    /* === First SHA-256: process 80-byte header === */
    uint32_t h1[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    /* SHA-256 expects big-endian input words; g_in is little-endian, so bswap each word */
    uint32_t w1[16];
    for (int i = 0; i < 16; i++) w1[i] = bswap32(g_in[i]);
    sha256d_transform(h1, w1);

    uint32_t w2[16];
    w2[0] = bswap32(g_in[16]); w2[1] = bswap32(g_in[17]); w2[2] = bswap32(g_in[18]); w2[3] = bswap32(nonce);
    w2[4] = 0x80000000; w2[5] = 0; w2[6] = 0; w2[7] = 0;
    w2[8] = 0; w2[9] = 0; w2[10] = 0; w2[11] = 0;
    w2[12] = 0; w2[13] = 0; w2[14] = 0; w2[15] = 0x00000280;
    sha256d_transform(h1, w2);

    /* h1 now contains the first SHA-256 hash in big-endian word order.
       For the second SHA-256, the input IS the hash output, which is already
       in the correct big-endian format for SHA-256 input. No bswap needed. */
    uint32_t h2[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                      0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    uint32_t m2[16];
    m2[0] = h1[0]; m2[1] = h1[1]; m2[2] = h1[2]; m2[3] = h1[3];
    m2[4] = h1[4]; m2[5] = h1[5]; m2[6] = h1[6]; m2[7] = h1[7];
    m2[8] = 0x80000000; m2[9] = 0; m2[10] = 0; m2[11] = 0;
    m2[12] = 0; m2[13] = 0; m2[14] = 0; m2[15] = 0x00000100;
    sha256d_transform(h2, m2);

    /* h2 is the final double-SHA256 hash in big-endian word order.
       h2[0] is the most significant word, matching our target format. */

    /* Debug: output hash of thread 0 for verification */
    if (tid == 0) {
        g_out[0x80] = h2[0]; g_out[0x81] = h2[1]; g_out[0x82] = h2[2]; g_out[0x83] = h2[3];
        g_out[0x84] = h2[4]; g_out[0x85] = h2[5]; g_out[0x86] = h2[6]; g_out[0x87] = h2[7];
    }

    /* Full 256-bit target comparison */
    if (hash_below_target(h2, t0, t1, t2, t3, t4, t5, t6, t7)) {
        uint32_t idx = atomic_inc(&g_out[0xFF]);
        if (idx < 0xFF) g_out[idx] = nonce;
    }
}
